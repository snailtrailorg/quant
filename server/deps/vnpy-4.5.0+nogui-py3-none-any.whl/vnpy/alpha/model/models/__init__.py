"""
Concrete alpha model implementations.
"""
