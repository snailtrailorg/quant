"""
Example alpha trading strategies.
"""
